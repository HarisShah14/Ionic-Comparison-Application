import { Component, OnInit } from '@angular/core';

import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { AuthenticationService } from './services/authentication.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent implements OnInit {

  userEmail: string;
  public selectedIndex = 0;
  public appPages = [
    {
      title: 'View Item List',
      url: '/welcome/',
      icon: 'cart'
    },
    {
      title: '    (Amazon) Laptops',
      url: '/amazon-laptop',
      icon: 'laptop'
    },
    {
      title: '    (Amazon) Mobiles',
      url: '/amazon-mobile',
      icon: 'phone-portrait'
    },
    {
      title: '    (Ebay) Laptops',
      url: '/ebay-laptop',
      icon: 'laptop'
    },
    {
      title: '    (Ebay) Mobiles',
      url: '/ebay-mobile',
      icon: 'phone-portrait'
    },
    {
      title: 'Favourites',
      url: '/favourites',
      icon: 'star'
    },
    {
      title: 'Compare',
      url: '/compare',
      icon: 'hammer'
    },
    {
      title: 'Messages',
      url: '/message',
      icon: 'chatbubbles'
    },

  ];

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private authService: AuthenticationService,

  ) 
  {
    this.initializeApp();
  }  
  

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }
  ngOnInit() {
    const path = window.location.pathname.split('folder/')[1];
    if (path !== undefined) {
      this.selectedIndex = this.appPages.findIndex(page => page.title.toLowerCase() === path.toLowerCase());
    }
    this.authService.userDetails().subscribe(res => {
      console.log('res', res);
      if (res !== null) {
        this.userEmail = res.email;
      } else {
        this.userEmail = "Guest";
      }
    }, err => {
      console.log('err', err);
    })
  }
}
