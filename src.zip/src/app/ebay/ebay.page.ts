import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-ebay',
  templateUrl: './ebay.page.html',
  styleUrls: ['./ebay.page.scss'],
})
export class EbayPage implements OnInit {

  userEmail: string;
  constructor(private authService: AuthenticationService, private navCtrl: NavController) { }

  ngOnInit() {
    this.authService.userDetails().subscribe(res => {
      console.log('res', res);
      if (res !== null) {
        this.userEmail = res.email;
      } else {
        this.userEmail = "Guest";
        this.navCtrl.navigateForward('/login');
      }
    }, err => {
      console.log('err', err);
    })
  }

}
