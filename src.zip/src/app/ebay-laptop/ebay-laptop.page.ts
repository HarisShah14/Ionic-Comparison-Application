import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';
import { ToastController } from '@ionic/angular';
import { NavController } from '@ionic/angular';
import {FBsrvService, fav, amazonLap } from '../services/fbsrv.service';
import { Observable } from 'rxjs';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-ebay-laptop',
  templateUrl: './ebay-laptop.page.html',
  styleUrls: ['./ebay-laptop.page.scss'],
})
export class EbayLaptopPage implements OnInit {

  public amazonLap: Observable<amazonLap[]>;

  private favs: Observable<fav[]>;
  private fav : fav = {} as fav;
  userEmail: string;

  constructor(public DataSrv:DataService, public toastController:ToastController, 
    private favService: FBsrvService, private authService: AuthenticationService,
    private navCtrl: NavController) { }

  ngOnInit() {
    this.favs = this.favService.getfavs();
    this.amazonLap = this.favService.getamazonLaps();

    this.authService.userDetails().subscribe(res => {
      console.log('res', res);
      if (res !== null) {
        this.userEmail = res.email;
      } else {
        this.userEmail = "Guest";
        this.navCtrl.navigateForward('/login');
      }
    }, err => {
      console.log('err', err);
    })
  }

  search =[];
  empty =[];
  
  async addFav(fav, userEmail){
    this.favService.addFav(fav, this.userEmail).then( (response)=>{
    alert("Favourited!");
    });
  }

  initializeItems() {
    this.search = this.DataSrv.ebayLaptopList;
  }

  getItems(ev) {
    // Reset items back to all of the items
    this.initializeItems();

    // set val to the value of the ev target
    var val = ev.target.value;

    // if the value is an empty string don't filter the items
    if (val && val.trim() != '') {
      this.search = this.search.filter((list) => {
        return (list.name.toLowerCase().indexOf(val.toLowerCase()) > -1);
      })
    }
    else
      this.search = this.empty;
  }


}
