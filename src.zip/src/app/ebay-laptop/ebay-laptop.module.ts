import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { EbayLaptopPageRoutingModule } from './ebay-laptop-routing.module';

import { EbayLaptopPage } from './ebay-laptop.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    EbayLaptopPageRoutingModule
  ],
  declarations: [EbayLaptopPage]
})
export class EbayLaptopPageModule {}
