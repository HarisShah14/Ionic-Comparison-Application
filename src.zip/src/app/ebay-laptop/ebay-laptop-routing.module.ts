import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { EbayLaptopPage } from './ebay-laptop.page';

const routes: Routes = [
  {
    path: '',
    component: EbayLaptopPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class EbayLaptopPageRoutingModule {}
