import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { EbayLaptopPage } from './ebay-laptop.page';

describe('EbayLaptopPage', () => {
  let component: EbayLaptopPage;
  let fixture: ComponentFixture<EbayLaptopPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EbayLaptopPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(EbayLaptopPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
