import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';
import { ToastController } from '@ionic/angular';
import { NavController } from '@ionic/angular';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-amazon',
  templateUrl: './amazon.page.html',
  styleUrls: ['./amazon.page.scss'],
})
export class AmazonPage implements OnInit {
  userEmail: string;

  constructor(public DataSrv:DataService, public toastController:ToastController, 
    private authService: AuthenticationService, private navCtrl: NavController) { }

  ngOnInit() {
    this.authService.userDetails().subscribe(res => {
      console.log('res', res);
      if (res !== null) {
        this.userEmail = res.email;
      } else {
        this.userEmail = "Guest";
        this.navCtrl.navigateForward('/login');
      }
    }, err => {
      console.log('err', err);
    })
  }


}
