import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';
import { ToastController } from '@ionic/angular';
import { NavController } from '@ionic/angular';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-compare',
  templateUrl: './compare.page.html',
  styleUrls: ['./compare.page.scss'],
})
export class ComparePage implements OnInit {

  constructor(public DataSrv:DataService, public toastController:ToastController,
    private authService: AuthenticationService, private navCtrl: NavController) { }
  
  userEmail:string;
  show = false;
  mobile = false;

  price = "Undetermined";
  processor = "Undetermined";
  generation = "Undetermined";
  ram = "Undetermined";
  storage = "Undetermined";
  storageSpeed = "Undetermined";
  l1flag = 0;
  l2flag = 0;
  overall = "Undetermined";

  showM = false;
  priceM = "Undetermined";
  dataM = "Undetermined";
  ramM = "Undetermined";
  storageM = "Undetermined";
  displayM = "Undetermined";
  m1flag = 0;
  m2flag = 0;
  overallM = "Undetermined";

  compare(lists1, lists2){
    this.show = true;
    //compare price
    if(lists1.price < lists2.price){
      this.price = lists1.name + " is cheaper than " + lists2.name;
      this.l1flag++;
    }
    else if(lists1.price > lists2.price){
      this.price = lists2.name + " is cheaper than " + lists1.name;
      this.l2flag++;
    }
    else
      this.price = "Both " +lists1.name + " and " + lists2.name + " have the same price!";
    //compare processor
    if(lists1.processor > lists2.processor){
      this.processor = lists1.name + " has a better processor with more cores, threads and better clock speed than " + lists2.name;
      this.l1flag++;
    }
    else if(lists1.price < lists2.price){
      this.processor = lists2.name + " has a better processor with more cores, threads and better clock speed than " + lists1.name;
      this.l2flag++;
    }
    else
      this.processor = "Both " + lists1.name + " and " + lists2.name + " have the same processor!";
    //compare generation
    if(lists1.generation > lists2.generation){
      this.generation = lists1.name  + " is of a higher generation, this usually mean improved performance and beeter support."
      this.l1flag++;
    }
    else if (lists1.generation < lists2.generation){
      this.generation = lists2.name  + " is of a higher generation, this usually mean improved performance and beeter support."
      this.l2flag++;
    }
    else
      this.generation = "Both items have the same generation of processor."
    //compare storage
    if(lists1.storage > lists2.storage){
      this.storage = lists1.name  + " has higher storage capacity."
      this.l1flag++;
    }
    else if(lists1.storage < lists2.storage){
      this.storage = lists2.name  + " has higher storage capacity."
      this.l2flag++;
    }
    else
      this.storage = "Both items have the same storage capacity!"
    //compare ram
    if(lists1.ram > lists2.ram){
      this.ram = lists1.name + " has a more RAM, this will help decrease load times and increase performance during multitasking when compared to " + lists2.name;
      this.l1flag++;
    }
    else if(lists1.ram < lists2.ram){
      this.ram = lists2.name + " has a more RAM, this will help decrease load times and increase performance during multitasking when compared to " + lists1.name;
      this.l2flag++;
    }
    else
      this.ram = "Both " + lists1.name + " and " + lists2.name + " have the same ram!";
    //compare overall
    if(this.l1flag > this.l2flag){
      this.overall = lists1.name + " got an overall score of " + this.l1flag + "/5 making it the better choice";
    }
    else if (this.l1flag < this.l2flag){
      this.overall = lists2.name + " got an overall score of " + this.l2flag + "/5 making it the better choice";
    }
    else
      this.overall = "It seems like both items have roughly the same specifications, pick whatever you like!"
  }

  async deleteItem(item){
    let alrt= await this.toastController.create({
      message:"Item deleted succesfully",
      duration: 2000
      });
      alrt.present();
    this.DataSrv.compare.splice(this.DataSrv.compare.indexOf(item),1);
    this.price = "Undetermined";
    this.processor = "Undetermined";
    this.generation = "Undetermined";
    this.ram = "Undetermined";
    this.storage = "Undetermined";
    this.storageSpeed = "Undetermined";
    this.l1flag = 0;
    this.l2flag = 0;
    this.overall = "Undetermined";
    this.show = false;
  }

  async deleteItemM(item){
    let alrt= await this.toastController.create({
      message:"Item deleted succesfully",
      duration: 2000
      });
      alrt.present();
    this.DataSrv.compareM.splice(this.DataSrv.compareM.indexOf(item),1);
    this.price = "Undetermined";
    this.processor = "Undetermined";
    this.generation = "Undetermined";
    this.ram = "Undetermined";
    this.storage = "Undetermined";
    this.storageSpeed = "Undetermined";
    this.l1flag = 0;
    this.l2flag = 0;
    this.overall = "Undetermined";
    this.showM = false;
  }

  compareM(lists1, lists2){
    this.showM = true;
    //compare price
    if(lists1.price < lists2.price){
      this.priceM = lists1.name + " is cheaper than " + lists2.name;
      this.m1flag++;
    }
    else if(lists1.price > lists2.price){
      this.priceM = lists2.name + " is cheaper than " + lists1.name;
      this.m2flag++;
    }
    else
      this.priceM = "Both " +lists1.name + " and " + lists2.name + " have the same price!";
    //compare processor
    if(lists1.displayM > lists2.displayM){
      this.displayM = lists1.name + " has a bigger display than " + lists2.name;
      this.m1flag++;
    }
    else if(lists1.displayM < lists2.displayM){
      this.displayM = lists2.name + " has a bigger display than" + lists1.name;
      this.m2flag++;
    }
    else
      this.displayM = "Both " + lists1.name + " and " + lists2.name + " have the same display size!";
    //compare generation
    if(lists1.data > lists2.data){
      this.dataM = lists1.name  + " supports faster internet speeds."
      this.m1flag++;
    }
    else if (lists1.data < lists2.data){
      this.dataM = lists2.name  + " supports faster internet speeds."
      this.m2flag++;
    }
    else
      this.dataM = "Both items have the same generation of processor."
    //compare storage
    if(lists1.storage > lists2.storage){
      this.storageM = lists1.name  + " has higher storage capacity."
      this.m1flag++;
    }
    else if(lists1.storage < lists2.storage){
      this.storageM = lists2.name  + " has higher storage capacity."
      this.m2flag++;
    }
    else
      this.storageM = "Both items have the same storage capacity!"
    //compare ram
    if(lists1.ram > lists2.ram){
      this.ramM = lists1.name + " has a more RAM, this will help decrease load times and increase performance during multitasking when compared to " + lists2.name;
      this.m1flag++;
    }
    else if(lists1.ram < lists2.ram){
      this.ramM = lists2.name + " has a more RAM, this will help decrease load times and increase performance during multitasking when compared to " + lists1.name;
      this.m2flag++;
    }
    else
      this.ramM = "Both " + lists1.name + " and " + lists2.name + " have the same ram!";
    //compare overall
    if(this.l1flag > this.l2flag){
      this.overallM = lists1.name + " got an overall score of " + this.m1flag + "/5 making it the better choice";
    }
    else if (this.l1flag < this.l2flag){
      this.overallM = lists2.name + " got an overall score of " + this.m2flag + "/5 making it the better choice";
    }
    else
      this.overallM = "It seems like both items have roughly the same specifications, pick whatever you like!"
  }

  flagger(){
    this.mobile = !this.mobile;
  }

  ngOnInit() {
    this.authService.userDetails().subscribe(res => {
      console.log('res', res);
      if (res !== null) {
        this.userEmail = res.email;
      } else {
        this.userEmail = "Guest";
        this.navCtrl.navigateForward('/login');
      }
    }, err => {
      console.log('err', err);
    })
  }

}
