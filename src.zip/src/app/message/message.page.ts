import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { NavController } from '@ionic/angular';
import {FBsrvService, message} from '../services/fbsrv.service';
import { Observable } from 'rxjs';
import { AuthenticationService } from '../services/authentication.service';
@Component({
  selector: 'app-message',
  templateUrl: './message.page.html',
  styleUrls: ['./message.page.scss'],
})
export class MessagePage implements OnInit {

  public message: Observable<message[]>;

  userEmail: string;
  pid: number;
  to: string;
  content: string;

  constructor(
    private router: Router, 
    private activatedRoute: ActivatedRoute,
    public toastController:ToastController, 
    private authService: AuthenticationService,
    private favService: FBsrvService,
    private navCtrl: NavController
  ) { }

  ngOnInit() {

    this.message = this.favService.getMsg();
    this.authService.userDetails().subscribe(res => {
      console.log('res', res);
      if (res !== null) {
        this.userEmail = res.email;
      } else {
        this.userEmail = "Guest";
        this.navCtrl.navigateForward('/welcome');
      }
    }, err => {
      console.log('err', err);
    })

  }
  nav(){
    this.navCtrl.navigateBack('');
  }

  
}


