import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';
import {FBsrvService, fav, amazonLap, comment, rate } from '../services/fbsrv.service';
import { Observable } from 'rxjs';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-info',
  templateUrl: './info.page.html',
  styleUrls: ['./info.page.scss'],
})
export class InfoPage implements OnInit {

  constructor(
    private router: Router, 
    private activatedRoute: ActivatedRoute,
    public toastController:ToastController, 
    private favService: FBsrvService,
    private authService: AuthenticationService,
    private navCtrl: NavController
    ) { }
 
  pid: number;
  public amazonLap: Observable<amazonLap[]>;
  public comment: Observable<comment[]>;
  public rate: Observable<rate[]>;
  private favs: Observable<fav[]>;
  private fav : fav = {} as fav;
  userEmail: string;
  text: string;
  value: number;
  showComms = true;
  totalRate: number;
  showMsg = false;
  to: string;
  content: string;

  ngOnInit() {
    
    this.favs = this.favService.getfavs();
    this.amazonLap = this.favService.getamazonLaps();
    this.comment = this.favService.getComms();
    this.rate = this.favService.getRate();

    this.activatedRoute.paramMap.subscribe(paramMap => {
      if (!paramMap.has('id')) {
        this.router.navigate(['/']);
      }
      this.pid = +paramMap.get('id');
    });

    this.authService.userDetails().subscribe(res => {
      console.log('res', res);
      if (res !== null) {
        this.userEmail = res.email;
      } else {
        this.userEmail = "Guest";
        this.navCtrl.navigateForward('/login');
      }
    }, err => {
      console.log('err', err);
    })
  }

  async saveComment(id, userEmail,text){
    this.favService.addComms(this.pid, this.userEmail, this.text).then( (response)=>{
    alert("Favourited!");
    });
  }

  public ratingArr= [
  {
    value: 1,
    icon: "star-outline"
  },
  {
    value: 2,
    icon: "star-outline"
  },
  {
    value: 3,
    icon: "star-outline"
  },
  {
    value: 4,
    icon: "star-outline"
  },
  {
    value: 5,
    icon: "star-outline"
  }
];

setRating(val: number){
  for (var i = 0; i < this.ratingArr.length; i++) {
  if (i < val) {
     this.ratingArr[i].icon = 'star';
     this.value = val;
  } 
  else {
     this.ratingArr[i].icon = 'star-outline';
     this.value = val;
    }
  } 
 }

 async saveRate(id, userEmail,value){
  this.favService.addRate(this.pid, this.userEmail, this.value).then( (response)=>{
  alert("Rating Saved!");
  });
}

flagger(){
  this.showComms = !this.showComms;
}

async addFav(fav, userEmail){
  this.favService.addFav(fav, this.userEmail).then( (response)=>{
  alert("Favourited!");
  });
}
showMg(){
  this.showMsg = !this.showMsg;
}
sendMsg(content, userEmail, pid, to){
  this.showMsg = !this.showMsg;
  this.favService.addMsg(this.content, this.userEmail, this.pid, this.to).then( (response)=>{
    alert("Message Sent but may not have been delivered if the user isn't registered.");
    });
}
}
