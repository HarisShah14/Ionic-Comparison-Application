import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AmazonLaptopPageRoutingModule } from './amazon-laptop-routing.module';

import { AmazonLaptopPage } from './amazon-laptop.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AmazonLaptopPageRoutingModule
  ],
  declarations: [AmazonLaptopPage]
})
export class AmazonLaptopPageModule {}
