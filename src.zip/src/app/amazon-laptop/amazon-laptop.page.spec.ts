import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AmazonLaptopPage } from './amazon-laptop.page';

describe('AmazonLaptopPage', () => {
  let component: AmazonLaptopPage;
  let fixture: ComponentFixture<AmazonLaptopPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AmazonLaptopPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AmazonLaptopPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
