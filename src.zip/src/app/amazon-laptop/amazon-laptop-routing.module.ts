import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AmazonLaptopPage } from './amazon-laptop.page';

const routes: Routes = [
  {
    path: '',
    component: AmazonLaptopPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AmazonLaptopPageRoutingModule {}
