import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';
import { ToastController } from '@ionic/angular';
import { NavController } from '@ionic/angular';
import {FBsrvService, fav, amazonLap, amazonMob, favMob } from '../services/fbsrv.service';
import { Observable } from 'rxjs';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-favourites',
  templateUrl: './favourites.page.html',
  styleUrls: ['./favourites.page.scss'],
}) 

export class FavouritesPage implements OnInit {
  private favs: Observable<fav[]>;
  public amazonMob: Observable<amazonMob[]>;

  private favMobs: Observable<favMob[]>;

  constructor(public DataSrv:DataService, public toastController:ToastController, 
    private favService: FBsrvService, private authService: AuthenticationService,
    private navCtrl: NavController) { }

  
  search =[];
  empty =[];
  userEmail: string;
  mobile = false;

  initializeItems() {
    this.search = this.DataSrv.amazonLaptopList;
  }

  getItems(ev) {
    // Reset items back to all of the items
    this.initializeItems();

    // set val to the value of the ev target
    var val = ev.target.value;

    // if the value is an empty string don't filter the items
    if (val && val.trim() != '') {
      this.search = this.search.filter((list) => {
        return (list.name.toLowerCase().indexOf(val.toLowerCase()) > -1);
      })
    }
    else
      this.search = this.empty;
  }

  async deleteItem(item){
    let alrt= await this.toastController.create({
      message:"Item deleted succesfully",
      duration: 2000
      });
      alrt.present();
    this.DataSrv.favourites.splice(this.DataSrv.favourites.indexOf(item),1);
  }

  async compareAdd(lists){
    if (this.DataSrv.compare.length > 2){
      let alrt= await this.toastController.create({
        message:"Your comparing list is full! please clear it before adding more items.",
        duration: 2000
        });
        alrt.present();
    }
    else 
    {
      this.DataSrv.compare.push ({name: lists.name, price: lists.price, processor: lists.processor, generation: lists.generation, ram: lists.ram, storage: lists.storage, type: lists.type, display: lists.display, additional: lists.additional, pic: lists.pic});
      let alrt= await this.toastController.create({
        message:"Added to Comparison List, view your list from the sidemenu.",
        duration: 2000
        });
      alrt.present();
      }
    } 

    async compareAddM(lists){
      if (this.DataSrv.compareM.length > 2){
        let alrt= await this.toastController.create({
          message:"Your comparing list is full! please clear it before adding more items.",
          duration: 2000
          });
          alrt.present();
      }
      else 
      {
        this.DataSrv.compareM.push ({name: lists.name, price: lists.price, ram: lists.ram, data: lists.data, display: lists.display, pic: lists.pic, storage: lists.storage});
        let alrt= await this.toastController.create({
          message:"Added to Comparison List, view your list from the sidemenu.",
          duration: 2000
          });
        alrt.present();
        }
      } 

  async deleteFav(item){
    this.favService.deleteFav(item).then( (response)=>{
    alert("Favourite Deleted");
    });
  }

  async deleteFavM(item){
    this.favService.deleteFavM(item).then( (response)=>{
    alert("Favourite Deleted");
    });
  }

  flagger(){
    this.mobile = !this.mobile;
  }
  
  ngOnInit() {
    this.favs = this.favService.getfavs();
    this.favMobs = this.favService.getfavsMob();
    this.amazonMob = this.favService.getamazonMobs();

    this.authService.userDetails().subscribe(res => {
      console.log('res', res);
      if (res !== null) {
        this.userEmail = res.email;
      } else {
        this.userEmail = "Guest";
        this.navCtrl.navigateForward('/login');
      }
    }, err => {
      console.log('err', err);
    })
  }

}
