import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';
import { ToastController } from '@ionic/angular';
import { NavController } from '@ionic/angular';
import {FBsrvService, fav, amazonMob, favMob } from '../services/fbsrv.service';
import { Observable } from 'rxjs';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-amazon-mobile',
  templateUrl: './amazon-mobile.page.html',
  styleUrls: ['./amazon-mobile.page.scss'],
})
export class AmazonMobilePage implements OnInit {

  public amazonMob: Observable<amazonMob[]>;

  private mobfavs: Observable<favMob[]>;
  private mobFav : favMob = {} as favMob;
  userEmail: string;

  constructor(public DataSrv:DataService, public toastController:ToastController, 
    private favService: FBsrvService, private authService: AuthenticationService,
    private navCtrl: NavController) { }
  ngOnInit() {
    this.mobfavs = this.favService.getfavsMob();
    this.amazonMob = this.favService.getamazonMobs();

    this.authService.userDetails().subscribe(res => {
      console.log('res', res);
      if (res !== null) {
        this.userEmail = res.email;
      } else {
        this.userEmail = "Guest";
        this.navCtrl.navigateForward('/login');
      }
    }, err => {
      console.log('err', err);
    })
  }

  async addFav(mobFav, userEmail){
    this.favService.addFavM(mobFav, this.userEmail).then( (response)=>{
    alert("Favourited!");
    });
  }

}
