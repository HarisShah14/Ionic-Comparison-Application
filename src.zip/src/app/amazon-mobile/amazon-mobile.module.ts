import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AmazonMobilePageRoutingModule } from './amazon-mobile-routing.module';

import { AmazonMobilePage } from './amazon-mobile.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AmazonMobilePageRoutingModule
  ],
  declarations: [AmazonMobilePage]
})
export class AmazonMobilePageModule {}
