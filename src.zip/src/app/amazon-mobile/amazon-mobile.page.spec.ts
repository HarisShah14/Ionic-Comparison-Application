import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AmazonMobilePage } from './amazon-mobile.page';

describe('AmazonMobilePage', () => {
  let component: AmazonMobilePage;
  let fixture: ComponentFixture<AmazonMobilePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AmazonMobilePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AmazonMobilePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
