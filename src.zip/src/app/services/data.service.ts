import { NullTemplateVisitor } from '@angular/compiler';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  compare = [
    {name: null, price: null, processor: null, generation: null, ram: null, storage: null, type: null, display: null, additional: null, pic: null},

  ];
  compareM = [
    {name: null, price: null, ram: null, data: null, display: null, pic: null, storage: null},

  ];
  favourites = [
    {name: null, price: null, processor: null, generation: null, ram: null, storage: null, type: null, display: null, additional: null, pic: null},

  ];
  amazonLaptopList = [
    {name: "Dell Laptop", price: "199.999", processor: "5", generation: 10, ram: "4", 
    storage: "500", type: "SSD", display: "1080p-60Hz", 
    additional: "Upto 800 nits of peak brightness", pic: "dell.jfif"},
    
    {name: "HP Laptop", price: "349.999", processor: "7", generation: 10, ram: "8", 
    storage: "512", type: "SSD", display: "1080p-60Hz", 
    additional: "Anti glare screen, Upto 1200 nits of brightness", pic: "hp.jpg"}
  ];

  ebayLaptopList = [
    {name: "Omen by Hp", price: "199.999", processor: "5", generation: 10, ram: "4", 
    storage: "500", type: "SSD", display: "1080p-60Hz", 
    additional: "Upto 800 nits of peak brightness", pic: "omen.jpg"}
  ];

  constructor() { }
  
}
