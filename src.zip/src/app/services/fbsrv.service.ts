import { Injectable } from '@angular/core';

import { AngularFirestore} from '@angular/fire/firestore';
import { AngularFirestoreCollection } from '@angular/fire/firestore';
import { DocumentReference } from '@angular/fire/firestore';
import { first, map, take } from 'rxjs/operators';
import { Observable, Subscription } from 'rxjs';

export interface fav {
  ID?: string,
  item: amazonLap,
  email: string
}
export interface amazonLap {
  ID: string,
  additional: string,
  display: string,
  email: string,
  generation: number,
  name: string,
  pic: string,
  price: number,
  processor: number,
  ram: number,
  storage: number,
  storageType: string,
  storeID: number
  }
export interface amazonMob {
  data: number,
  display: number,
  name: string,
  pic: string,
  ID: string,
  price: number,
  ram: number,
  storage: number,
  storeID: number,
  }

  export interface favMob {
    ID?: string,
    item: amazonMob,
    email: string
  }

export interface comment{
  ID: number,
  email: string,
  text: string
}
export interface rate{
  ID : number,
  email : string,
  value : number
}
export interface message{
  content: string,
  from: string,
  pid: number,
  to: string
}

@Injectable({
  providedIn: 'root'
})
export class FBsrvService {

  public fav: Observable<fav[]>;
  public favCollection: AngularFirestoreCollection<fav>;

  public favMob: Observable<favMob[]>;
  public favMobCollection: AngularFirestoreCollection<favMob>;

  public amazonLap: Observable<amazonLap[]>;
  public amazonLapCollection: AngularFirestoreCollection<amazonLap>;

  public amazonMob: Observable<amazonMob[]>;
  public amazonMobCollection: AngularFirestoreCollection<amazonMob>;

  public comment: Observable<comment[]>;
  public commentCollection: AngularFirestoreCollection<comment>;

  public rate: Observable<rate[]>;
  public rateCollection: AngularFirestoreCollection<rate>;

  public message: Observable<message[]>;
  public messageCollection: AngularFirestoreCollection<message>;

  subs:Subscription;
  constructor(private afs: AngularFirestore) { 
  //favs
  this.favCollection = this.afs.collection<fav>('fav');
  this.fav = this.favCollection.snapshotChanges().pipe(
  map(actions => 
  {
  return actions.map(a => 
    {
    const data = a.payload.doc.data();
    const id = a.payload.doc.id;
    return { id, ...data };
    });
  }));
  //favMob
  this.favMobCollection = this.afs.collection<favMob>('favMob');
  this.favMob = this.favMobCollection.snapshotChanges().pipe(
  map(actions => 
  {
  return actions.map(a => 
    {
    const data = a.payload.doc.data();
    const id = a.payload.doc.id;
    return { id, ...data };
    });
  }));
  //amazonLaptop
  this.amazonLapCollection = this.afs.collection<amazonLap>('amazonLap');
  this.amazonLap = this.amazonLapCollection.snapshotChanges().pipe(
  map(actions => 
  {
  return actions.map(a => 
    {
    const data = a.payload.doc.data();
    const id = a.payload.doc.id;
    return { id, ...data };
    });
  }));
  //amazonMob
  this.amazonMobCollection = this.afs.collection<amazonMob>('amazonMob');
  this.amazonMob = this.amazonMobCollection.snapshotChanges().pipe(
  map(actions => 
  {
  return actions.map(a => 
    {
    const data = a.payload.doc.data();
    const id = a.payload.doc.id;
    return { id, ...data };
    });
  }));
  //comment
  this.commentCollection = this.afs.collection<comment>('comment');
  this.comment = this.commentCollection.snapshotChanges().pipe(
  map(actions => 
  {
  return actions.map(a => 
    {
    const data = a.payload.doc.data();
    const id = a.payload.doc.id;
    return { id, ...data };
    });
  }));
  //rate
  this.rateCollection = this.afs.collection<rate>('rate');
  this.rate = this.rateCollection.snapshotChanges().pipe(
  map(actions => 
  {
  return actions.map(a => 
    {
    const data = a.payload.doc.data();
    const id = a.payload.doc.id;
    return { id, ...data };
    });
  }));
  //message
  this.messageCollection = this.afs.collection<message>('message');
  this.message = this.messageCollection.snapshotChanges().pipe(
  map(actions => 
  {
  return actions.map(a => 
    {
    const data = a.payload.doc.data();
    const id = a.payload.doc.id;
    return { id, ...data };
    });
  }));

  }

  getamazonLaps(): Observable<amazonLap[]> {
    return this.amazonLap;
  }

  getamazonMobs(): Observable<amazonMob[]> {
    return this.amazonMob;
  }

  getfavs(): Observable<fav[]> {
    return this.fav;
  }

  getfavsMob(): Observable<favMob[]> {
    return this.favMob;
  }

  getComms(): Observable<comment[]> {
    return this.comment;
  }

  getMsg(): Observable<message[]> {
    return this.message;
  }

  getRate(): Observable<rate[]> {
    return this.rate;
  }

  addFav(item: amazonLap, email:string): Promise<DocumentReference> {
    return this.favCollection.add({item:item, email});
  }

  addFavM(item: amazonMob, email:string): Promise<DocumentReference> {
    return this.favMobCollection.add({item:item, email});
  }

  addComms(ID:number, email:string, text:string): Promise<DocumentReference> {
    return this.commentCollection.add({ID, email, text});
  }

  deleteFav(ID:string): Promise<void> {
    return this.favCollection.doc(ID).delete();
  } 

  deleteFavM(ID:string): Promise<void> {
    return this.favMobCollection.doc(ID).delete();
  } 
  
  addRate(ID:number, email:string, value:number): Promise<DocumentReference> {
    return this.rateCollection.add({ID, email, value});
  }
  addMsg(content:string, from:string, pid:number, to:string): Promise<DocumentReference> {
    return this.messageCollection.add({content, from, pid, to});
  }
}
